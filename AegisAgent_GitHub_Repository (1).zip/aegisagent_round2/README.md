# AegisAgent - Adaptive Agentic Prompt Injection Firewall

**ET AI Hackathon: Agentic Edition | Round 2 Prototype**

AegisAgent is a working AI security prototype that intercepts user messages, web pages, PDFs/text, email/markdown/html/API content and tool requests before they influence an AI agent. It detects, sanitizes, blocks and explains prompt-injection attacks with an agent flight recorder and red-team evaluation arena.

## Why this solution

The problem statement asks for a Prompt Injection Firewall that detects and neutralizes malicious instructions embedded in incoming content before they influence AI behavior. AegisAgent goes beyond a simple classifier by adding:

- Multi-layer threat detection for 9 attack categories
- Intent/data separation for retrieved or external content
- Tool action guard for preventing exfiltration and unauthorized actions
- Canary vault to catch secret leakage attempts
- Autonomous red-team agent that generates and tests attacks
- Agent flight recorder for auditability, observability and explainability

## Claimed feature/depth position

- **Feature level:** F3 - detects 7+ attack types
- **Depth level:** D2 - structured and textual heterogeneous sources with demonstrable reliability
- **Stretch:** D3-ready design when image OCR and multimodal ingestion are enabled

## Attack types covered

1. Instruction Override
2. Role Change
3. Secret Extraction
4. Tool Abuse
5. Credential Theft
6. Context Poisoning
7. Multi-Step Jailbreaks
8. Encoded Instructions
9. Indirect Prompt Injection

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

## Demo flow

1. Open the Dashboard.
2. Analyze a normal user message.
3. Analyze the malicious HTML sample from `data/demo/malicious_webpage.html`.
4. Try the Base64 encoded attack from `data/demo/encoded_attack.txt`.
5. Attempt a dangerous tool call such as `send_email` with `CANARY_API_KEY_X7`.
6. Run the Red-Team Evaluation Arena.
7. Show the Agent Flight Recorder and risk explanation.

## Repository structure

```text
app/                     Streamlit UI
agents/                  Firewall, detector, red-team and flight recorder
guardrails/              Policy checks and canary vault
evaluation/              Test cases and evaluation runner
data/demo/               Safe and malicious demo inputs
docs/                    Architecture and demo script
```

## Responsible AI and safety controls

- Human approval for high-risk actions
- No raw secret exposure in outputs
- Risk scoring with evidence
- Audit trail for every decision
- Defensive-only red-team examples
- Explainable allow / sanitize / block decisions

## Limitations

This prototype is optimized for hackathon demonstration. Production deployment would require stronger model evaluation, enterprise policy integration, secure logging, file sandboxing, OCR hardening and continuous monitoring.

# AegisAgent Architecture

```text
Incoming content / tool request
        |
        v
Input Normalizer -> Threat Detection Ensemble -> Risk Engine
        |                    |                      |
        |                    v                      v
        |             Pattern + Semantic       ALLOW / SANITIZE / BLOCK
        |                    |                      |
        v                    v                      v
Intent/Data Separation -> Canary Vault -> Tool Guard -> Human Approval
        |
        v
Safe downstream agent context
```

## Agent flow

Observe incoming content, normalize it, detect suspicious instruction intent, score risk, sanitize or block, validate tool calls and record each decision in the flight recorder.

## Demo architecture claim

- F3: detects 7+ attack types
- D2: reliable structured and textual inputs
- D3-ready: OCR/image input can be connected through the same normalizer
